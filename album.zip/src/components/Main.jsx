/** @format */
import "./main.css";
import { useEffect, useState } from "react";
function Main() {
	const [data, setData] = useState([]);
	const [songs, setSong] = useState([]);
	var album = JSON.parse(localStorage.getItem("album"));

	useEffect(() => {
		get();
	}, []);
	const get = async () => {
		let res = await fetch("http://localhost:3004/songs");
		const data = await res.json();

		await filt(data);
	};

	function filt(el) {
		const arr = el.filter((e) => {
			return e.artist == album.artist;
		});

		setSong(arr);
	}
	console.log(songs);
	return (
		<div>
			<div id='container'>
				<div style={{ float: "left" }}>
					<img src={album.cover} alt='' id='cover' />
				</div>
				<div style={{ float: "left", width: "650px" }}>
					<img src={album.img} id='author' />
				</div>
				<div id='name'>{album.artist}</div>
				<div style={{ clear: "both" }}></div>
				<h1 style={{ textAlign: "center", fontWeight: "30px" }}>List</h1>
				<div>
					{songs.map((e, i) => (
						<div>
							<div style={{ float: "left", marginLeft: "100px" }}>
								<img src={e.is1} alt='' width='70px' />
								<div className='sss'>{e.song1}</div>
							</div>
							<div style={{ float: "left", marginLeft: "100px" }}>
								{" "}
								<img src={e.is2} alt='' width='70px' />{" "}
								<div className='sss'>{e.song2}</div>
							</div>
							<div style={{ float: "left", marginLeft: "100px" }}>
								{" "}
								<img src={e.is3} alt='' width='70px' />{" "}
								<div className='sss'>{e.song3}</div>
							</div>
							<div style={{ float: "left", marginLeft: "100px" }}>
								{" "}
								<img src={e.is4} alt='' width='70px' />{" "}
								<div className='sss'>{e.song4}</div>
							</div>
						</div>
					))}
				</div>
			</div>
		</div>
	);
}
export default Main;
{
	/* {data.map((e) => (
				<div>
					<div>{e.artist}</div>
					<div>{e.song1}</div>
					<div>{e.song2}</div>
				</div>
			))} */
}
